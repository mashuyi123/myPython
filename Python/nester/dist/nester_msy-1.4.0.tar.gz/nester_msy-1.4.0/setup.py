from distutils.core import setup

setup(
		name = 'nester_msy',
		version = '1.4.0',
		py_modules = ['nester'],
		author = 'msy_python',
		author_email = '1763360594@qq.com',
		url = 'www.mashuyi.com',
		description = 'A simple printer of nested list',
	)